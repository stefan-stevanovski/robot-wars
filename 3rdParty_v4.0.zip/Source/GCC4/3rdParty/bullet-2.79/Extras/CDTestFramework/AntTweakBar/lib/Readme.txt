These files are part of the AntTweakBar library.
http://www.antisphere.com/Wiki/tools:anttweakbar

Copyright � 2005, 2006 Philippe Decaudin.
AntTweakBar is a free software released under the zlib license.
For conditions of distribution and use, see ../License.txt
